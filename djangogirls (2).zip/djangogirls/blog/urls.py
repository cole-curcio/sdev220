from django.shortcuts import render
from django.urls import path
from . import views

def post_list(request):
    return render(request, 'blog/post_list.html', {})

urlpatterns = [
    path('', views.post_list, name='post_list')
]
